package com.demo.postservice.controller;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author siddu
 *
 */
public class PostControllerTest {
	
	private static Logger logger = LoggerFactory.getLogger(PostControllerTest.class);

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSavPost() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindPostById() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPosts() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllPosts() {
		fail("Not yet implemented");
	}

}
