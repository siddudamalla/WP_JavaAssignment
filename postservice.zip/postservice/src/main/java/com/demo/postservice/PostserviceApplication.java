package com.demo.postservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author siddu
 *PostService
 */
@SpringBootApplication
public class PostserviceApplication {
	
	private static Logger logger = LoggerFactory.getLogger(PostserviceApplication.class);

	public static void main(String[] args) {
		logger.info("Started PostService : PostserviceApplication:main()......");
		SpringApplication.run(PostserviceApplication.class, args);
		logger.info("End PostService : PostserviceApplication:main()......");
	}

}
