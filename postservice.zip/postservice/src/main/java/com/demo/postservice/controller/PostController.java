package com.demo.postservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.postservice.entity.Post;
import com.demo.postservice.service.PostService;

/**
 * @author siddu
 *This PostController is controller class for all endpont urls
 */
@RestController
@RequestMapping("/posts")
public class PostController {
	
	private static Logger logger = LoggerFactory.getLogger(PostController.class);
	
	@Autowired
	private PostService postService;
	
	@PostMapping("/save")
	public Post savPost(@RequestBody Post post) {
		logger.info("Enter In PostController:savPost()......");
		return postService.savPost(post);
	}
	
	/*@GetMapping("/{id}")
	public Post findPostById(@PathVariable("id") Long id) {
		logger.info("Enter In PostController:findPostById()......");
		return postService.findPostById(id);
	}*/
	
	@GetMapping("/all")
	public List<Post> getPosts() {
		logger.info("Enter In PostController:getPosts()......");
		return postService.getPosts();
		
	}
	
	@GetMapping("/siddu")
	public List<Post> getAllPosts() {
		logger.info("Enter In PostController:getAllPosts()......");
		return postService.getPosts();
		
	}
	
	@GetMapping("/kundan")
	public List<Post> getAllPosts1() {
		logger.info("Enter In PostController:getAllPosts1()......");
		return postService.getPosts();
		
	}
	
	
	@GetMapping("/{postBy}")
	public List<Post> findPostByUser(@PathVariable("postBy") String postBy) {
		logger.info("Enter In PostController:findPostByUser()......");
		String name = postBy.split("=")[1];
		List<Post> postsByUser= postService.getPosts();
		List<Post> postsByUserOnly=  new ArrayList<Post>();
		for(Post post : postsByUser) {
			if(post.getPostBy().equals(name)) {
			postsByUserOnly.add(post);
			}
		}
		return postsByUserOnly;
	}

}
