package com.demo.postservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.postservice.entity.Post;
import com.demo.postservice.repository.PostRepository;

/**
 * @author siddu
 * 
 *This PostService provide service logic for CRUD operations
 */
@Service
public class PostService {
	
	private static Logger logger = LoggerFactory.getLogger(PostService.class);
	
	@Autowired
	private PostRepository postRepository;

	public Post savPost(Post post) {
		logger.info("Enter In PostService:savPost()......");
		return postRepository.save(post);
	}

	public Post findPostById(Long id) {
		logger.info("Enter In PostService:findPostById()......");
		return postRepository.findPostById(id);
	}

	public List<Post> getPosts() {
		logger.info("Enter In PostService:getPosts()......");
		List<Post> posts = postRepository.findAll();
		return posts;
	}
	
	

}
