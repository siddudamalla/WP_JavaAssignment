package com.demo.userservice.controller;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.demo.userservice.repository.UserRepository;
import com.demo.userservice.service.UserService;
import com.demo.userservice.testdata.UserData;

class UserControllerTest {
	
	private Logger logger = LoggerFactory.getLogger(UserControllerTest.class);
	
	@InjectMocks
	private UserService userService;
	 @Mock
	private UserRepository userRepository;

	@BeforeEach
	void setUp() throws Exception {
		
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testSaveUser() {
		logger.info("Enter testSaveUser....");
//		userService.saveUser(UserData.getUserData());
		logger.info("Exit testSaveUser....");
	}

	@Test
	void testGetUserWithPost() {
		fail("Not yet implemented");
	}

	@Test
	void testGetUsers() {
		fail("Not yet implemented");
	}

}
