package com.demo.userservice.testdata;

import com.demo.userservice.entity.User;

public class UserData {
	
	public static User getUserData() {
		User u = new User(100L, "fName1", "lName1", "siddu@gmail.com", "Address1", 33, 1L, "siddu");
		return u;
	}

}
