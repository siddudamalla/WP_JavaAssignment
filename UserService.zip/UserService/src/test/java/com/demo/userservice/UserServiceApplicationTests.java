package com.demo.userservice;


import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.demo.userservice.repository.UserRepository;
import com.demo.userservice.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
class UserServiceApplicationTests {
	
	@Mock
	private UserRepository userRepository;
	@Autowired
	private UserService userService;

	@Test
	public void getUsersTest() {
//		User u = new User(100L, "fName1", "lName1", "siddu@gmail.com", "Address1", 33, 1L, "siddu");
		/*when(userRepository.findAll()).thenReturn(Stream.of(new User(100L, "fName1", "lName1", "siddu@gmail.com", "Address1", 33, 1L, "siddu"),
				new User(200L, "fName11", "lName11", "siddu@gmail1.com", "Address11", 34, 2L, "siddu")));*/
	}


}
