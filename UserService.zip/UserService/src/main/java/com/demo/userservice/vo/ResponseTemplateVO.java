package com.demo.userservice.vo;

import java.util.List;

/**
 * @author siddu
 * 
 * ResponseTemplate is Value Object which is used to store User and related Posts data
 *
 */
public class ResponseTemplateVO {
	
	private List<ResponseTemplate> responseTemplate;

	public List<ResponseTemplate> getResponseTemplate() {
		return responseTemplate;
	}

	public void setResponseTemplate(List<ResponseTemplate> responseTemplate) {
		this.responseTemplate = responseTemplate;
	}
	
	
	
	

}
