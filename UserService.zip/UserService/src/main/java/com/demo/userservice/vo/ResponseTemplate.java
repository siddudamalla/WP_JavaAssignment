package com.demo.userservice.vo;

import java.util.List;

import com.demo.userservice.entity.User;

/**
 * @author siddu
 * 
 * ResponseTemplate is Value Object which is used to store User and related Posts data
 *
 */
public class ResponseTemplate {
	
	private List<Object> posts;
	private User user;
	
	public List<Object> getPosts() {
		return posts;
	}
	public void setPosts(List<Object> posts) {
		this.posts = posts;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	

}
