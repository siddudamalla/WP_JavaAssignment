package com.demo.userservice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.demo.userservice.entity.User;
import com.demo.userservice.repository.UserRepository;
import com.demo.userservice.vo.Post;
import com.demo.userservice.vo.ResponseTemplate;
import com.demo.userservice.vo.ResponseTemplateVO;

/**
 * @author siddu
 * This UserService is service class for all User CRUD operations
 */
@Service
public class UserService {
	
	private Logger logger = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RestTemplate restTemplate;

	/**
	 * This Method sued to User
	 * @param user
	 * @return User
	 */
	public User saveUser(User user) {
		
		logger.info("In UserService:saveUser()......");
		
		return userRepository.save(user);
		
	}

	/**
	 * This Method is used to find user by Id
	 * @param userId
	 * @return User
	 */
	public User findUserById(Long userId) {
		logger.info("In UserService:findUserById()......");
		
		 return userRepository.findUserById(userId);
	}

	/**
	 * This Method is used to find user by Id and respective posts using RestTemplate call for PostSerivce API
	 * @param userId
	 * @return ResponseTemplate
	 */
	public ResponseTemplate getUserWithPost(Long userId) {
		logger.info("Enter in UserService:getUserWithPost()......");
		ResponseTemplate responseTemplate = new ResponseTemplate();
		User user = userRepository.findUserById(userId);
		Object[] posts = restTemplate.getForObject("http://localhost:9002/posts/"+user.getPostBy(), Object[].class);
		responseTemplate.setPosts(Arrays.asList(posts));
		responseTemplate.setUser(user);
		logger.info("Exit  UserService:getUserWithPost......");
		return responseTemplate;
	}

	/**
	 * his Method is used to find all Users
	 * @return List<User>
	 */
	public List<User> getUsers() {
		logger.info("Enter in UserService:getUsers()......");
		return userRepository.findAll();
	}

	/**
	 * @return ResponseTemplateVO
	 */
	public ResponseTemplateVO getAllUsersWithAllPosts() {
		
		logger.info("Enter in UserService:getAllUsersWithAllPosts()......");
		ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
		List<ResponseTemplate> list = new ArrayList<ResponseTemplate>();
		List<User> users = userRepository.findAll();
		
		for(User userObj : users) {
			ResponseTemplate responseTemplate = new ResponseTemplate();
			User user = userRepository.findUserById(userObj.getId());
			String url = "http://localhost:9002/posts/postBy="+user.getPostBy();
			Object[] posts = restTemplate.getForObject(url, Object[].class);
//			Object[] posts = restTemplate.getForObject("http://localhost:9002/posts/{"+user.getPostBy()+"}", Object[].class);
			responseTemplate.setPosts(Arrays.asList(posts));
			responseTemplate.setUser(user);
			list.add(responseTemplate);
			posts = null;
		}
		responseTemplateVO.setResponseTemplate(list);
		return responseTemplateVO;
	}

}
