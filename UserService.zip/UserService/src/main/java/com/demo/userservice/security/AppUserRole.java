package com.demo.userservice.security;

import java.util.Set;

import com.google.common.collect.Sets;

/**
 * @author siddu
 *this  Enum provides UserRole
 */
public enum AppUserRole {
	
	USER(Sets.newHashSet(AppUserPermission.USER_READ, AppUserPermission.POST_READ)),
	ADMIN(Sets.newHashSet(AppUserPermission.USER_READ , AppUserPermission.USER_WRITE ,AppUserPermission.POST_READ, AppUserPermission.POST_WRITE));
	
	
	private final Set<AppUserPermission> permission;
	
	AppUserRole(Set<AppUserPermission> permission){
		this.permission = permission;
	}

}
