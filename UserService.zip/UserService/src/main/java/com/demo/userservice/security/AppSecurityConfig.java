package com.demo.userservice.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import com.demo.userservice.controller.UserController;

/**
 * @author siddu
 *
 */
@Configuration
@EnableWebSecurity
public class AppSecurityConfig extends WebSecurityConfigurerAdapter{
	
	private Logger logger = LoggerFactory.getLogger(AppSecurityConfig.class);
	
	private final PasswordEncoder passwordEncoder;
	@Autowired
	public AppSecurityConfig(PasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.web.builders.HttpSecurity)
	 * This method providing basic Authentication  and URL based Authentication.
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		logger.info("Enter In AppSecurityConfig:configure()......");
		http.csrf().disable();
		http.authorizeRequests()
		    .antMatchers("/users/all", "/users/allusers").hasRole(AppUserRole.ADMIN.name())
		    .anyRequest()
		    .fullyAuthenticated()
		    .and()
		    .httpBasic();
		logger.info("Exit In AppSecurityConfig:configure()......");
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#userDetailsService()
	 * 
	 * This method is creating users and respective passwords and roles using In Memory API 
	 */
	@Override
	@Bean
	protected UserDetailsService userDetailsService() {
		logger.info("Enter In AppSecurityConfig:userDetailsService()......");
		UserDetails userDetails = User.builder()
		    .username("MYUSER")
		    .password(passwordEncoder.encode("User123"))
		    .roles(AppUserRole.USER.name()) //ROLE_USER
		    .build();
		UserDetails adminDetails = User.builder()
			    .username("MYADMIN")
			    .password(passwordEncoder.encode("Admin123"))
			    .roles(AppUserRole.ADMIN.name()) //ROLE_ADMIN
			    .build();
		logger.info("Exit In AppSecurityConfig:userDetailsService()......");
		return new InMemoryUserDetailsManager(userDetails, adminDetails);
	}

}
