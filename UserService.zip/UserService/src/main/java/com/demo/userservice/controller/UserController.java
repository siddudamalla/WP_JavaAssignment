package com.demo.userservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.userservice.entity.User;
import com.demo.userservice.service.UserService;
import com.demo.userservice.vo.ResponseTemplate;
import com.demo.userservice.vo.ResponseTemplateVO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author siddu
 * 
 * This Controller class for all end point urls from UserSerive API 
 *
 */
@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {
	
	private Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	/**
	 * This Method used to create new User
	 * @param user
	 * @return User
	 */
	@RequestMapping("/save")
	public User saveUser(@RequestBody User user) {
		logger.info("Enter In UserController:saveUser()......");
		
		return userService.saveUser(user);
		
	}
	/**
	 * This Method used to get User information along with related posts
	 * @param userId
	 * @return ResponseTemplate
	 */
	@GetMapping("/{id}")
	public ResponseTemplate getUserWithPost(@PathVariable("id") Long userId) {
		logger.info("Enter In UserController:getUserWithPost()......");
		return userService.getUserWithPost(userId);
	}
	
	
	/**
	 * This Method used to get All Users information
	 * @return  List<User>
	 */
	@GetMapping("/all")
	public List<User> getUsers() {
		logger.info("Enter In UserController:getUsers()......");
		return userService.getUsers();
		
	}
	
	/**
	 * This Method used to get All Users information
	 * @return  List<User>
	 */
	@GetMapping("/allusers")
	public ResponseTemplateVO getAllUsersWithAllPosts() {
		logger.info("Enter In UserController:getAllUsersWithAllPosts()......");
		return userService.getAllUsersWithAllPosts();
		
	}

}
