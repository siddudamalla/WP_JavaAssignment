package com.demo.userservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author siddu
 *This User class is Entity to interact with Data base
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
	@Id
	@GeneratedValue	(strategy = GenerationType.AUTO)
	private Long id;
	private String firstName;
	private String lastName;
	private String mailId;
	private String address;
	private Integer age;
	private Long postId;
	private String postBy;
	
	public User() {
		
	}
	
	public User(Long id, String firstName, String lastName, String mailId, String address, Integer age, Long postId,
			String postBy) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mailId = mailId;
		this.address = address;
		this.age = age;
		this.postId = postId;
		this.postBy = postBy;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getPostId() {
		return postId;
	}
	public void setPostId(Long postId) {
		this.postId = postId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPostBy() {
		return postBy;
	}
	public void setPostBy(String postBy) {
		this.postBy = postBy;
	}
	
    
}
