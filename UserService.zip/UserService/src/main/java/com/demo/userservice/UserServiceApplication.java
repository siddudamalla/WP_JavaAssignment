package com.demo.userservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * @author siddu
 *  UserServiceApplication
 */
@SpringBootApplication
public class UserServiceApplication {
	
	private static Logger logger = LoggerFactory.getLogger(UserServiceApplication.class);

	public static void main(String[] args) {
		logger.info("Started UserService : UserServiceApplication:main()......");
		SpringApplication.run(UserServiceApplication.class, args);
		logger.info("End UserService : UserServiceApplication:main()......");
	}
	
	@Bean
	public RestTemplate getRestTemplate() {
		logger.info("Enter UserServiceApplication:getRestTemplate()......");
		return new RestTemplate();
	}

}
